const express = require('express');
const router = express.Router();

// Import controller functions from equipmentSearchController
const {
  searchEquipment,
  getAllEquipment,
  sendContactRequest
} = require('../controllers/equipmentSearchController');

// Search equipment
router.post('/search', searchEquipment);

// Get all equipment (for initial load)
router.get('/', getAllEquipment);

// Send contact request to equipment owner
router.post('/contact', sendContactRequest);

module.exports = router;