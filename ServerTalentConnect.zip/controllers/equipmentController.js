// equipmentController.js - For equipment creation and profile management
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { db } = require('../config/db');
const { cleanupUploadedFiles } = require('../middleware/registerMiddleware');

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const uploadPath = file.fieldname === 'equipmentImages' ? 'uploads/equipment-images/' : 'uploads/certificates/';
    
    if (!fs.existsSync(uploadPath)) {
      fs.mkdirSync(uploadPath, { recursive: true });
    }
    
    cb(null, uploadPath);
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const fileFilter = (req, file, cb) => {
  if (file.fieldname === 'equipmentImages') {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed for equipment images'), false);
    }
  } else if (file.fieldname === 'certificateFiles') {
    if (file.mimetype.startsWith('image/') || file.mimetype === 'application/pdf') {
      cb(null, true);
    } else {
      cb(new Error('Only image files and PDFs are allowed for certificates'), false);
    }
  } else {
    cb(new Error('Unexpected field'), false);
  }
};

const upload = multer({
  storage: storage,
  fileFilter: fileFilter,
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB per file
    files: 20
  }
}).fields([
  { name: 'equipmentImages', maxCount: 10 },
  { name: 'certificateFiles', maxCount: 5 }
]);

// Create equipment table
const createEquipmentTable = () => {
  return new Promise((resolve, reject) => {
    const createTableQuery = `
      CREATE TABLE IF NOT EXISTS equipment (
        id INT PRIMARY KEY AUTO_INCREMENT,
        equipmentName VARCHAR(255) NOT NULL,
        equipmentType VARCHAR(100) NOT NULL,
        category VARCHAR(100) NOT NULL,
        location VARCHAR(255),
        contactPerson VARCHAR(100) NOT NULL,
        contactNumber VARCHAR(20) NOT NULL,
        email VARCHAR(255) NOT NULL,
        rentalPrice DECIMAL(10, 2) DEFAULT 0.00,
        priceType ENUM('hourly', 'daily', 'weekly', 'monthly') DEFAULT 'daily',
        description TEXT,
        specifications JSON,
        availability ENUM('available', 'rented') DEFAULT 'available',
        minRentalPeriod VARCHAR(50),
        maxRentalPeriod VARCHAR(50),
        deliveryAvailable BOOLEAN DEFAULT FALSE,
        deliveryRadius VARCHAR(100),
        \`condition\` ENUM('excellent', 'good', 'fair', 'needs_repair') DEFAULT 'excellent',
        equipmentImages JSON,
        certificateFiles JSON,
        isActive BOOLEAN DEFAULT TRUE,
        createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_category (category),
        INDEX idx_availability (availability),
        INDEX idx_location (location),
        INDEX idx_equipment_type (equipmentType),
        INDEX idx_price (rentalPrice),
        INDEX idx_condition (\`condition\`)
      )
    `;

    db.query(createTableQuery, (err) => {
      if (err) {
        console.error('Error creating equipment table:', err.message);
        return reject(err);
      }
      resolve();
    });
  });
};

// Create contact inquiries table
const createContactInquiriesTable = () => {
  return new Promise((resolve, reject) => {
    const createTableQuery = `
      CREATE TABLE IF NOT EXISTS contact_inquiries (
        id INT AUTO_INCREMENT PRIMARY KEY,
        equipment_id INT NOT NULL,
        requester_name VARCHAR(255) NOT NULL,
        requester_email VARCHAR(255) NOT NULL,
        requester_phone VARCHAR(20),
        message TEXT NOT NULL,
        status ENUM('pending', 'responded', 'resolved') DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        
        INDEX idx_equipment_id (equipment_id),
        INDEX idx_requester_email (requester_email),
        INDEX idx_created_at (created_at),
        
        FOREIGN KEY (equipment_id) REFERENCES equipment(id) ON DELETE CASCADE
      )
    `;

    db.query(createTableQuery, (err) => {
      if (err) {
        console.error('Error creating contact_inquiries table:', err.message);
        return reject(err);
      }
      resolve();
    });
  });
};

// Initialize tables
let tablesInitialized = false;
const initializeTables = async () => {
  if (!tablesInitialized) {
    try {
      // Create equipment table first (since contact_inquiries references it)
      await createEquipmentTable();
      console.log('Equipment table initialized successfully');
      
      // Create contact inquiries table
      await createContactInquiriesTable();
      console.log('Contact inquiries table initialized successfully');
      
      tablesInitialized = true;
      console.log('All tables initialized successfully');
    } catch (error) {
      console.error('Failed to initialize tables:', error);
    }
  }
};

initializeTables();

// Validation functions
const validateRequiredFields = ({ equipmentName, equipmentType, category, contactPerson, contactNumber, email }) => {
  const errors = [];

  if (!equipmentName || equipmentName.trim().length < 2) errors.push('Equipment name must be at least 2 characters');
  if (!equipmentType || equipmentType.trim().length < 2) errors.push('Equipment type is required');
  if (!category || category.trim().length < 2) errors.push('Category is required');
  if (!contactPerson || contactPerson.trim().length < 2) errors.push('Contact person is required');
  if (!contactNumber || contactNumber.trim().length < 8) errors.push('Valid contact number is required');
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) errors.push('Valid email is required');

  return {
    isValid: errors.length === 0,
    message: errors.length > 0 ? errors.join(', ') : null
  };
};

// Process specifications helper
const processSpecifications = (specifications) => {
  let specsArray = [];
  
  if (!specifications) return specsArray;
  
  if (Array.isArray(specifications)) {
    specsArray = specifications;
  } else if (typeof specifications === 'string') {
    const trimmed = specifications.trim();
    
    if (trimmed === '' || trimmed === '[]') {
      return specsArray;
    }
    
    if (trimmed.startsWith('[') && trimmed.endsWith(']')) {
      try {
        const parsed = JSON.parse(trimmed);
        if (Array.isArray(parsed)) {
          specsArray = parsed;
        }
      } catch (jsonError) {
        console.warn('Failed to parse specifications JSON:', jsonError.message);
        specsArray = trimmed.split(',').map(s => s.trim()).filter(s => s.length > 0);
      }
    } else {
      specsArray = trimmed.split(',').map(s => s.trim()).filter(s => s.length > 0);
    }
  }
  
  specsArray = specsArray
    .map(spec => String(spec).trim())
    .filter(spec => spec.length > 0 && spec.length <= 100)
    .slice(0, 10);
  
  return specsArray;
};

// Database operations
const insertEquipment = (equipmentData) => {
  return new Promise((resolve, reject) => {
    const query = `
      INSERT INTO equipment (
        equipmentName, equipmentType, category, location, contactPerson, contactNumber,
        email, rentalPrice, priceType, description, specifications, availability,
        minRentalPeriod, maxRentalPeriod, deliveryAvailable, deliveryRadius,
        \`condition\`, equipmentImages, certificateFiles
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;
    
    const values = [
      equipmentData.equipmentName,
      equipmentData.equipmentType,
      equipmentData.category,
      equipmentData.location,
      equipmentData.contactPerson,
      equipmentData.contactNumber,
      equipmentData.email,
      equipmentData.rentalPrice,
      equipmentData.priceType,
      equipmentData.description,
      JSON.stringify(equipmentData.specifications),
      equipmentData.availability,
      equipmentData.minRentalPeriod,
      equipmentData.maxRentalPeriod,
      equipmentData.deliveryAvailable,
      equipmentData.deliveryRadius,
      equipmentData.condition,
      JSON.stringify(equipmentData.equipmentImages),
      JSON.stringify(equipmentData.certificateFiles)
    ];

    db.query(query, values, (err, result) => {
      if (err) return reject(err);
      resolve(result.insertId);
    });
  });
};

const rollbackTransaction = () => {
  return new Promise((resolve) => {
    db.rollback(() => {
      console.log('Transaction rolled back');
      resolve();
    });
  });
};

// Main equipment creation function
const createEquipment = async (req, res) => {
  const startTime = Date.now();
  console.log(`[${startTime}] === EQUIPMENT CREATION REQUEST START ===`);
  
  try {
    // Handle file upload
    upload(req, res, async function (err) {
      if (err) {
        console.error('File upload error:', err);
        return res.status(400).json({
          success: false,
          msg: 'File upload failed: ' + err.message,
          timestamp: new Date().toISOString()
        });
      }

      try {
        console.log('Request details:', {
          method: req.method,
          contentType: req.headers['content-type'],
          bodyKeys: Object.keys(req.body || {}),
          fileKeys: req.files ? Object.keys(req.files) : 'No files'
        });

        const {
          equipmentName, equipmentType, category, location, contactPerson, contactNumber,
          email, rentalPrice, priceType, description, specifications, availability,
          minRentalPeriod, maxRentalPeriod, deliveryAvailable, deliveryRadius, condition
        } = req.body;

        // Validate required fields
        console.log('Validating required fields...');
        const validationResult = validateRequiredFields({
          equipmentName, equipmentType, category, contactPerson, contactNumber, email
        });

        if (!validationResult.isValid) {
          console.log(`[${startTime}] Equipment creation failed - validation error:`, validationResult.message);
          cleanupUploadedFiles(req);
          return res.status(400).json({ 
            success: false, 
            msg: validationResult.message,
            timestamp: new Date().toISOString()
          });
        }

        console.log('Basic validation passed, starting database transaction...');

        // Start transaction
        await new Promise((resolve, reject) => {
          db.beginTransaction((err) => {
            if (err) {
              console.error('Transaction start error:', err);
              return reject(err);
            }
            resolve();
          });
        });

        try {
          // Process file uploads
          const equipmentImages = req.files?.equipmentImages?.map(file => ({
            filename: file.filename,
            originalName: file.originalname,
            path: file.path,
            size: file.size
          })) || [];

          const certificateFiles = req.files?.certificateFiles?.map(file => ({
            filename: file.filename,
            originalName: file.originalname,
            path: file.path,
            size: file.size
          })) || [];

          // Process specifications
          const parsedSpecifications = processSpecifications(specifications);

          // Prepare equipment data
          const equipmentData = {
            equipmentName: equipmentName.trim(),
            equipmentType: equipmentType.trim(),
            category: category.trim(),
            location: location?.trim() || '',
            contactPerson: contactPerson.trim(),
            contactNumber: contactNumber.trim(),
            email: email.trim().toLowerCase(),
            rentalPrice: parseFloat(rentalPrice) || 0,
            priceType: priceType || 'daily',
            description: description?.trim() || '',
            specifications: parsedSpecifications,
            availability: availability || 'available',
            minRentalPeriod: minRentalPeriod?.trim() || '',
            maxRentalPeriod: maxRentalPeriod?.trim() || '',
            deliveryAvailable: deliveryAvailable === 'true',
            deliveryRadius: deliveryRadius?.trim() || '',
            condition: condition || 'excellent',
            equipmentImages,
            certificateFiles
          };

          // Insert equipment
          const equipmentId = await insertEquipment(equipmentData);
          console.log(`Equipment created with ID: ${equipmentId}`);

          // Commit transaction
          await new Promise((resolve, reject) => {
            db.commit((err) => {
              if (err) {
                console.error('Transaction commit error:', err);
                return reject(err);
              }
              resolve();
            });
          });

          console.log(`[${startTime}] Equipment creation completed successfully`);

          const responseTime = Date.now() - startTime;
          res.status(201).json({
            success: true,
            msg: 'Equipment listed successfully! Your listing is now live.',
            data: {
              id: equipmentId,
              equipmentName: equipmentData.equipmentName,
              category: equipmentData.category,
              availability: equipmentData.availability
            },
            timestamp: new Date().toISOString(),
            processingTime: `${responseTime}ms`
          });

        } catch (dbError) {
          await rollbackTransaction();
          throw dbError;
        }

      } catch (error) {
        console.error(`[${startTime}] Equipment creation error:`, error);
        cleanupUploadedFiles(req);
        
        let statusCode = 500;
        let errorMessage = 'Server error during equipment creation. Please try again.';
        
        if (error.code === 'ECONNREFUSED') {
          statusCode = 503;
          errorMessage = 'Database connection failed. Please try again later.';
        }
        
        res.status(statusCode).json({ 
          success: false, 
          msg: errorMessage,
          timestamp: new Date().toISOString(),
          requestId: startTime
        });
      }
    });

  } catch (error) {
    console.error(`[${startTime}] Equipment creation controller error:`, error);
    res.status(500).json({
      success: false,
      msg: 'Internal server error',
      timestamp: new Date().toISOString()
    });
  }
  
};

module.exports = {
  createEquipment,
  createEquipmentTable,
  createContactInquiriesTable
};