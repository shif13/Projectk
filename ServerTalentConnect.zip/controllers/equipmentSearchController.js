const { db: searchDb } = require('../config/db');
const { sendEquipmentInquiryEmail } = require('../services/emailService');

const buildSearchQuery = (filters) => {
  let baseQuery = `
    SELECT 
      id, equipmentName, equipmentType, category, location, contactPerson, 
      contactNumber, email, rentalPrice, priceType, description, 
      specifications, availability, minRentalPeriod, maxRentalPeriod,
      deliveryAvailable, deliveryRadius, \`condition\`, equipmentImages,
      createdAt, updatedAt
    FROM equipment 
    WHERE isActive = TRUE
  `;
  
  const conditions = [];
  const values = [];

  // Keyword search
  if (filters.keyword && filters.keyword.trim()) {
    conditions.push(`(
      equipmentName LIKE ? OR 
      equipmentType LIKE ? OR 
      category LIKE ? OR 
      description LIKE ? OR
      JSON_SEARCH(specifications, 'one', ?, NULL, '$[*]') IS NOT NULL
    )`);
    const keywordParam = `%${filters.keyword.trim()}%`;
    values.push(keywordParam, keywordParam, keywordParam, keywordParam, `%${filters.keyword.trim()}%`);
  }

  // Location search
  if (filters.location && filters.location.trim()) {
    conditions.push('location LIKE ?');
    values.push(`%${filters.location.trim()}%`);
  }

  // Category filter
  if (filters.category && filters.category.trim()) {
    conditions.push('category = ?');
    values.push(filters.category.trim());
  }

  // Availability filter
  if (filters.availability && filters.availability.trim()) {
    conditions.push('availability = ?');
    values.push(filters.availability.trim());
  }

  // Condition filter
  if (filters.condition && filters.condition.trim()) {
    conditions.push('`condition` = ?');
    values.push(filters.condition.trim());
  }

  // Price range filter
  if (filters.priceRange && filters.priceRange.trim()) {
    switch (filters.priceRange) {
      case 'low':
        conditions.push('rentalPrice < 1000');
        break;
      case 'medium':
        conditions.push('rentalPrice >= 1000 AND rentalPrice <= 2500');
        break;
      case 'high':
        conditions.push('rentalPrice > 2500');
        break;
    }
  }

  // Combine conditions
  if (conditions.length > 0) {
    baseQuery += ' AND ' + conditions.join(' AND ');
  }

  // Add ordering
  baseQuery += ' ORDER BY createdAt DESC';

  return { query: baseQuery, values };
};

// Search equipment function
const searchEquipment = async (req, res) => {
  const startTime = Date.now();
  console.log(`[${startTime}] === EQUIPMENT SEARCH REQUEST START ===`);
  
  try {
    console.log('Search request details:', {
      method: req.method,
      body: req.body,
      query: req.query
    });

    // Get search parameters from request body or query params
    const searchParams = req.method === 'POST' ? req.body : req.query;
    
    const {
      keyword = '',
      location = '',
      category = '',
      availability = '',
      condition = '',
      priceRange = '',
      limit = 50,
      offset = 0
    } = searchParams;

    console.log('Processing search with filters:', {
      keyword, location, category, availability, condition, priceRange, limit, offset
    });

    // Build search query
    const { query, values } = buildSearchQuery({
      keyword, location, category, availability, condition, priceRange
    });

    // Add pagination
    const finalQuery = query + ' LIMIT ? OFFSET ?';
    const finalValues = [...values, parseInt(limit) || 50, parseInt(offset) || 0];

    console.log('Executing search query...');

    // Execute search query
    const searchResults = await new Promise((resolve, reject) => {
      searchDb.query(finalQuery, finalValues, (err, results) => {
        if (err) {
          console.error('Search query error:', err);
          return reject(err);
        }
        resolve(results);
      });
    });

    // Process results
    const processedResults = searchResults.map(item => {
      // Parse JSON fields safely
      let specifications = [];
      let equipmentImages = [];
      
      try {
        specifications = item.specifications ? JSON.parse(item.specifications) : [];
      } catch (e) {
        console.warn(`Failed to parse specifications for item ${item.id}`);
      }
      
      try {
        equipmentImages = item.equipmentImages ? JSON.parse(item.equipmentImages) : [];
      } catch (e) {
        console.warn(`Failed to parse equipment images for item ${item.id}`);
      }

      return {
        id: item.id,
        name: item.equipmentName,
        equipmentType: item.equipmentType,
        category: item.category,
        location: item.location,
        price: `₹${item.rentalPrice}/${item.priceType}`,
        pricePerDay: item.priceType === 'daily' ? item.rentalPrice : null,
        availability: item.availability,
        condition: item.condition,
        description: item.description,
        specifications,
        minRentalPeriod: item.minRentalPeriod,
        maxRentalPeriod: item.maxRentalPeriod,
        deliveryAvailable: item.deliveryAvailable,
        deliveryRadius: item.deliveryRadius,
        owner: item.contactPerson,
        phone: item.contactNumber,
        email: item.email,
        images: equipmentImages,
        image: equipmentImages.length > 0 ? equipmentImages[0].path : null,
        tags: [item.category, item.equipmentType, item.condition].filter(Boolean),
        createdAt: item.createdAt,
        updatedAt: item.updatedAt
      };
    });

    // Get total count for pagination
    const countQuery = `
      SELECT COUNT(*) as total 
      FROM equipment 
      WHERE isActive = TRUE
      ${values.length > 2 ? 'AND ' + buildSearchQuery({ keyword, location, category, availability, condition, priceRange }).query.split('WHERE isActive = TRUE AND ')[1].split(' ORDER BY')[0] : ''}
    `;

    const totalCount = await new Promise((resolve, reject) => {
      searchDb.query(countQuery, values.slice(0, -2), (err, results) => {
        if (err) {
          console.warn('Count query error:', err);
          return resolve(0);
        }
        resolve(results[0]?.total || 0);
      });
    });

    console.log(`[${startTime}] Search completed - found ${processedResults.length} items`);

    const responseTime = Date.now() - startTime;
    res.status(200).json({
      success: true,
      data: processedResults,
      pagination: {
        total: totalCount,
        limit: parseInt(limit) || 50,
        offset: parseInt(offset) || 0,
        hasMore: (parseInt(offset) || 0) + processedResults.length < totalCount
      },
      searchParams: {
        keyword, location, category, availability, condition, priceRange
      },
      timestamp: new Date().toISOString(),
      processingTime: `${responseTime}ms`
    });

  } catch (error) {
    console.error(`[${startTime}] Equipment search error:`, error);
    
    let statusCode = 500;
    let errorMessage = 'Server error during search. Please try again.';
    
    if (error.code === 'ECONNREFUSED') {
      statusCode = 503;
      errorMessage = 'Database connection failed. Please try again later.';
    }
    
    res.status(statusCode).json({ 
      success: false, 
      msg: errorMessage,
      timestamp: new Date().toISOString(),
      requestId: startTime
    });
  }
};

// Get all equipment (for initial load)
const getAllEquipment = async (req, res) => {
  const startTime = Date.now();
  console.log(`[${startTime}] === GET ALL EQUIPMENT REQUEST START ===`);
  
  try {
    const { limit = 20, offset = 0 } = req.query;

    const query = `
      SELECT 
        id, equipmentName, equipmentType, category, location, contactPerson, 
        contactNumber, email, rentalPrice, priceType, description, 
        specifications, availability, minRentalPeriod, maxRentalPeriod,
        deliveryAvailable, deliveryRadius, \`condition\`, equipmentImages,
        createdAt, updatedAt
      FROM equipment 
      WHERE isActive = TRUE AND availability = 'available'
      ORDER BY createdAt DESC
      LIMIT ? OFFSET ?
    `;

    const results = await new Promise((resolve, reject) => {
      searchDb.query(query, [parseInt(limit) || 20, parseInt(offset) || 0], (err, results) => {
        if (err) {
          console.error('Get all equipment query error:', err);
          return reject(err);
        }
        resolve(results);
      });
    });

    // Process results same as search
    const processedResults = results.map(item => {
      let specifications = [];
      let equipmentImages = [];
      
      try {
        specifications = item.specifications ? JSON.parse(item.specifications) : [];
      } catch (e) {
        console.warn(`Failed to parse specifications for item ${item.id}`);
      }
      
      try {
        equipmentImages = item.equipmentImages ? JSON.parse(item.equipmentImages) : [];
      } catch (e) {
        console.warn(`Failed to parse equipment images for item ${item.id}`);
      }

      return {
        id: item.id,
        name: item.equipmentName,
        equipmentType: item.equipmentType,
        category: item.category,
        location: item.location,
        price: `₹${item.rentalPrice}/${item.priceType}`,
        availability: item.availability,
        condition: item.condition,
        description: item.description,
        specifications,
        owner: item.contactPerson,
        phone: item.contactNumber,
        email: item.email,
        images: equipmentImages,
        image: equipmentImages.length > 0 ? equipmentImages[0].path : null,
        tags: [item.category, item.equipmentType, item.condition].filter(Boolean)
      };
    });

    console.log(`[${startTime}] Get all equipment completed - returned ${processedResults.length} items`);

    const responseTime = Date.now() - startTime;
    res.status(200).json({
      success: true,
      data: processedResults,
      timestamp: new Date().toISOString(),
      processingTime: `${responseTime}ms`
    });

  } catch (error) {
    console.error(`[${startTime}] Get all equipment error:`, error);
    res.status(500).json({ 
      success: false, 
      msg: 'Server error while fetching equipment. Please try again.',
      timestamp: new Date().toISOString()
    });
  }
};

const sendContactRequest = async (req, res) => {
  const startTime = Date.now();
  console.log(`[${startTime}] === CONTACT REQUEST START ===`);
  
  try {
    const { equipmentId, name, email, phone, message } = req.body;

    // Validate required fields
    if (!name || !email || !message || !equipmentId) {
      return res.status(400).json({
        success: false,
        msg: 'Name, email, message, and equipment ID are required',
        timestamp: new Date().toISOString()
      });
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({
        success: false,
        msg: 'Please provide a valid email address',
        timestamp: new Date().toISOString()
      });
    }

    console.log('Contact request details:', {
      equipmentId,
      requesterName: name,
      requesterEmail: email,
      requesterPhone: phone,
      messageLength: message.length
    });

    // Get equipment details from database
    const getEquipmentQuery = `
      SELECT 
        id, equipmentName, equipmentType, category, location, contactPerson, 
        contactNumber, email, rentalPrice, priceType, description, 
        availability, \`condition\`
      FROM equipment 
      WHERE id = ? AND isActive = TRUE
    `;

    const equipmentDetails = await new Promise((resolve, reject) => {
      searchDb.query(getEquipmentQuery, [equipmentId], (err, results) => {
        if (err) {
          console.error('Get equipment details error:', err);
          return reject(err);
        }
        resolve(results[0]);
      });
    });

    if (!equipmentDetails) {
      return res.status(404).json({
        success: false,
        msg: 'Equipment not found or no longer available',
        timestamp: new Date().toISOString()
      });
    }

    // Check if equipment has owner email
    if (!equipmentDetails.email) {
      return res.status(400).json({
        success: false,
        msg: 'Equipment owner contact information not available. Please try contacting by phone.',
        timestamp: new Date().toISOString()
      });
    }

    // Prepare equipment data for email
    const equipmentData = {
      id: equipmentDetails.id,
      name: equipmentDetails.equipmentName,
      price: `₹${equipmentDetails.rentalPrice}/${equipmentDetails.priceType}`,
      location: equipmentDetails.location,
      category: equipmentDetails.category,
      condition: equipmentDetails.condition,
      availability: equipmentDetails.availability,
      description: equipmentDetails.description,
      owner: equipmentDetails.contactPerson,
      email: equipmentDetails.email,
      phone: equipmentDetails.contactNumber
    };

    // Prepare inquiry data
    const inquiryData = {
      name: name.trim(),
      email: email.trim(),
      phone: phone ? phone.trim() : null,
      message: message.trim()
    };

    // Send email to equipment owner
    console.log(`[${startTime}] Sending email to equipment owner: ${equipmentDetails.email}`);
    const emailResult = await sendEquipmentInquiryEmail(equipmentData, inquiryData);

    if (emailResult.success) {
      console.log(`[${startTime}] Email sent successfully: ${emailResult.messageId}`);
      
      // Optionally save the inquiry to database for tracking
      try {
        const saveInquiryQuery = `
          INSERT INTO contact_inquiries 
          (equipment_id, requester_name, requester_email, requester_phone, message, created_at)
          VALUES (?, ?, ?, ?, ?, NOW())
        `;
        
        await new Promise((resolve, reject) => {
          searchDb.query(saveInquiryQuery, [equipmentId, name, email, phone, message], (err, result) => {
            if (err) {
              console.warn('Failed to save inquiry to database:', err);
              // Don't fail the whole request if logging fails
            }
            resolve(result);
          });
        });
        
        console.log(`[${startTime}] Contact inquiry saved to database`);
      } catch (dbError) {
        console.error('Failed to save inquiry to database:', dbError);
        // Continue anyway since email was sent successfully
      }

      const responseTime = Date.now() - startTime;
      res.status(200).json({
        success: true,
        msg: 'Your inquiry has been sent successfully! The equipment owner will contact you soon.',
        timestamp: new Date().toISOString(),
        processingTime: `${responseTime}ms`
      });

    } else {
      console.error(`[${startTime}] Email sending failed:`, emailResult.error);
      res.status(500).json({
        success: false,
        msg: 'Failed to send inquiry email. Please try contacting the owner directly.',
        ownerPhone: equipmentDetails.contactNumber,
        timestamp: new Date().toISOString()
      });
    }

  } catch (error) {
    console.error(`[${startTime}] Contact request error:`, error);
    
    let statusCode = 500;
    let errorMessage = 'Server error while sending contact request. Please try again.';
    
    if (error.code === 'ECONNREFUSED') {
      statusCode = 503;
      errorMessage = 'Database connection failed. Please try again later.';
    }
    
    res.status(statusCode).json({ 
      success: false, 
      msg: errorMessage,
      timestamp: new Date().toISOString(),
      requestId: startTime
    });
  }
};

module.exports = {
  searchEquipment,
  getAllEquipment,
  sendContactRequest
};